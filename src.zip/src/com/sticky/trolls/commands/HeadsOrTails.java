package com.sticky.trolls.commands;

import com.sticky.trolls.inventories.CoinFlip;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HeadsOrTails implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can flip a coin!");
            return true;
        }
        Player player = (Player) sender;
        Server server = sender.getServer();

        if(cmd.getName().equalsIgnoreCase("coinflip")) {
            CoinFlip gui = new CoinFlip();
            player.openInventory(gui.getInventory());
        }

        return true;
    }
}