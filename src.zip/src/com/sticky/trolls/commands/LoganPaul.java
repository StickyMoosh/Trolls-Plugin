package com.sticky.trolls.commands;

import org.bukkit.ChatColor;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LoganPaul implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) { return true; }
        Player player = (Player) sender;
        Server server = sender.getServer();

        if(cmd.getName().equalsIgnoreCase("loganpaul")) {
            if (args.length > 1) {
                player.sendMessage(ChatColor.RED + "That is too many arguments! The format of the command should be " + ChatColor.GOLD + "/loganpaul playername");
            } else {
                server.broadcastMessage(ChatColor.AQUA + "Ya yeet\n" +
                        ChatColor.GOLD +
                        "Ya yeet\n" +
                        ChatColor.AQUA + "Ya yeet\n" +
                        ChatColor.GOLD +
                        "Ya yeet\n" +
                        ChatColor.AQUA + "Ya yeet\n" +
                        ChatColor.GOLD +
                        "Ya yeet\n" +
                        ChatColor.AQUA + "Ya yeet\n" +
                        ChatColor.GOLD +
                        "Ya yeet\n" +
                        ChatColor.AQUA + "Ya yeet\n" +
                        ChatColor.GOLD +
                        "Ya yeet\n" +
                        ChatColor.AQUA + "Ya yeet\n" +
                        ChatColor.GOLD +
                        "Ya yeet\n" +
                        ChatColor.AQUA + "Ya yeet\n" +
                        ChatColor.GOLD +
                        "Ya yeet\n" +
                        ChatColor.AQUA + "Ya yeet\n" +
                        ChatColor.GOLD +
                        "Ya yeet\n" +
                        ChatColor.AQUA + "Ya yeet\n" +
                        ChatColor.GOLD +
                        "Ya yeet\n" +
                        ChatColor.AQUA + "Ya yeet\n" +
                        ChatColor.GOLD +
                        "Ya yeet\n" + ChatColor.AQUA + "Ya yeet\n" +
                        ChatColor.GOLD +
                        "Ya yeet\n");
                return true;
            }
        }
        return true;
    }
}
