package com.sticky.trolls.inventories;

import com.sticky.trolls.items.ItemManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CoinFlip implements InventoryHolder {

    private Inventory inv;

    public CoinFlip() {
        inv = Bukkit.createInventory(this, 9, "Coin Flip");
        init();
    }

    private void init() {
        ItemStack item;
        for (int i = 0; i < 4; i++) {
            item = createItem(ChatColor.BLUE + "Heads", Material.LAPIS_BLOCK, Collections.singletonList("Picks heads"));
            inv.setItem(i, item);
        }
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GREEN + "If you choose the ");
        lore.add(ChatColor.GREEN + "correct one, you will ");
        lore.add(ChatColor.GREEN + "get a prize. If you ");
        lore.add(ChatColor.GREEN + "choose incorrectly, ");
        lore.add(ChatColor.GREEN + "you will die.");
        item = createItem(ChatColor.AQUA + "Pick Heads or Tails", Material.BOOK, lore);
        inv.setItem(inv.firstEmpty(), item);

        for (int i = 5; i < 9; i++) {
            item = createItem(ChatColor.GOLD + "Tails", Material.GOLD_BLOCK, Collections.singletonList("Picks tails"));
            inv.setItem(i, item);
        }
    }

    private ItemStack createItem(String name, Material mat, List<String> lore) {
        ItemStack item = new ItemStack(mat, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }
}
