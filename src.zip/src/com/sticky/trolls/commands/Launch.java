package com.sticky.trolls.commands;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Launch implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) { return true; }
        Player player = (Player) sender;
        Server server = sender.getServer();

        if(cmd.getName().equalsIgnoreCase("launch")) {
            if (args.length > 1) {
                player.sendMessage(ChatColor.RED + "That is too many arguments! The format of the command should be " + ChatColor.GOLD + "/launch playername");
            } else {
                String name = args[0];
                Player target = server.getPlayer(args[0]);
                int x = player.getLocation().getBlockX();
                int y = player.getLocation().getBlockY();
                int z = player.getLocation().getBlockZ();
                Location launched = new Location(player.getWorld(), x, y + 100, z);
                target.teleport(launched);
                server.broadcastMessage(ChatColor.GOLD + name + " has been launched!");
                target.sendMessage(ChatColor.GOLD + "You have been launched!");
            }
        }
        return true;
    }
}
