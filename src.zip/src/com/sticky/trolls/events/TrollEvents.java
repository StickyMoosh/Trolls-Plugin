package com.sticky.trolls.events;

import com.sticky.trolls.items.ItemManager;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.block.Block;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerKickEvent;

public class TrollEvents implements Listener {

    @EventHandler
    public static void onPlayerKick(PlayerKickEvent event) {
        Player player = event.getPlayer();
        Server server = event.getPlayer().getServer();
        String name = player.getName();
        server.broadcastMessage(ChatColor.DARK_PURPLE + name + " has just been kicked from the server. You can laugh at them now.");
    }

    @EventHandler
    public static void onPlayerSmite(PlayerInteractEvent event) {
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            if (event.getItem() != null) {
                if (event.getItem().getItemMeta().equals(ItemManager.smitestick.getItemMeta())) {
                    Player player = event.getPlayer();
                    Block targetBlock = event.getClickedBlock();
                    int x = targetBlock.getLocation().getBlockX();
                    int y = targetBlock.getLocation().getBlockY();
                    int z = targetBlock.getLocation().getBlockZ();
                    Location blockLocation = new Location(targetBlock.getWorld(), x, y, z);
                    player.getWorld().strikeLightning(blockLocation);
                }
            }
        }
    }
}
