package com.sticky.trolls.commands;

import org.bukkit.ChatColor;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class JakePaul implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) { return true; }
        Player player = (Player) sender;
        Server server = sender.getServer();

        if(cmd.getName().equalsIgnoreCase("jakepaul")) {
            server.broadcastMessage(ChatColor.AQUA + "Y'all can't handle this\n" +
                    "Y'all don't know what's about to happen baby\n" +
                    "Team 10\n" +
                    "Los Angeles, Cali boy\n" +
                    "But I'm from Ohio though, white boy\n" +
                    "It's everyday bro, with the Disney Channel flow\n" +
                    "5 mill on YouTube in 6 months, never done before\n" +
                    "Passed all the competition man, PewDiePie is next\n" +
                    "Man I'm poppin' all these checks, got a brand new Rolex\n" +
                    "And I met a Lambo too and I'm coming with the crew\n" +
                    "This is Team 10, b***h, who the h**l are flippin' you?\n" +
                    "And you know I kick them out if they ain't with the crew\n" +
                    "Yeah, I'm talking about you, you beggin' for attention\n" +
                    "Talking s**t on Twitter too but you still hit my phone last night\n" +
                    "It was 4:52 and I got the text to prove\n" +
                    "And all the recordings too, don't make me tell them the truth\n" +
                    "And I just dropped some new merch and it's selling like a god, church\n" +
                    "Ohio's where I'm from, we chew 'em like it's gum\n" +
                    "We shooting with a gun, the tattoo just for fun\n" +
                    "I Usain Bolt and run, catch me at game one\n" +
                    "I cannot be outdone, Jake Paul is number one\n" +
                    "It's everyday bro\n" +
                    "It's everyday bro\n" +
                    "It's everyday bro\n" +
                    "I said it is everyday bro!\n" +
                    ChatColor.LIGHT_PURPLE +
                    "You know it's Nick Crompton and my collar stay poppin'\n" +
                    "Yes, I can rap and no, I am not from Compton\n" +
                    "England is my city\n" +
                    "And if it weren't for Team 10, then the US would be s****y\n" +
                    "I'll pass it to Chance 'cause you know he stay litty\n" +
                    ChatColor.GREEN +
                    "Two months ago you didn't know my name\n" +
                    "And now you want my fame? B***h I'm blowin' up\n" +
                    "I'm only going up, now I'm going off, I'm never fallin' off\n" +
                    "Like Mag, who? Digi who? Who are you?\n" +
                    "All these beefs I just ran through, hit a milli in a month\n" +
                    "Where were you? Hatin' on me back in West Fake\n" +
                    "You need to get your shit straight\n" +
                    "Jakey brought me to the top, now we're really poppin' off\n" +
                    "Number one and number four, that's why these fans all at our door\n" +
                    "It's lonely at the top so we all going\n" +
                    "We left Ohio, now the trio is all rollin'\n" +
                    "It's Team 10, b***h\n" +
                    "We back again, always first, never last\n" +
                    "We the future, we'll see you in the past\n" +
                    ChatColor.AQUA +
                    "It's everyday bro\n" +
                    "It's everyday bro\n" +
                    "It's everyday bro\n" +
                    "I said it is everyday bro!\n" +
                    ChatColor.GOLD +
                    "Hold on, hold on, hold on, hold on (espera)\n" +
                    "Can we switch the language? (Ha, ya tú sabes)\n" +
                    "We 'bout to hit it (dale)\n" +
                    "Sí, lo único que quiero es dinero\n" +
                    "Trabajando en YouTube todo el día entero\n" +
                    "Viviendo en U.S.A, el sueño de cualquiera\n" +
                    "Enviando dólares a mi familia entera\n" +
                    "Tenemos una persona por encima\n" +
                    "Se llama Donald Trump y está en la cima\n" +
                    "Desde aquí te cantamos can I get my VISA?\n" +
                    "Martinez Twins, representando España\n" +
                    "Desde la pobreza a la fama\n" +
                    ChatColor.AQUA +
                    "It's everyday bro\n" +
                    "It's everyday bro\n" +
                    "It's everyday bro\n" +
                    "I said it is everyday bro!\n" +
                    ChatColor.DARK_PURPLE +
                    "Yo, it's Tessa Brooks\n" +
                    "The competition shook\n" +
                    "These guys up on me\n" +
                    "I got 'em with the hook\n" +
                    "Lemme educate ya'\n" +
                    "And I ain't talking book\n" +
                    "Panera is your home?\n" +
                    "So, stop calling my phone\n" +
                    "I'm flyin' like a drone\n" +
                    "They buying like a loan\n" +
                    "Yeah, I smell good\n" +
                    "Is that your boy's cologne?\n" +
                    ChatColor.AQUA +
                    "Is that your boy's cologne?\n" +
                    "Started balling', quicken Loans\n" +
                    "Now I'm in my flippin' zone\n" +
                    "Yes, they all copy me\n" +
                    "But, that's some s****y clones\n" +
                    "Stay in all designer clothes\n" +
                    "And they ask me what I make\n" +
                    "I said is 10 with six zeros\n" +
                    "Always plug, merch link in bio\n" +
                    "And I will see you tomorrow 'cause it's everyday bro\n" +
                    "Peace\n" +
                    ChatColor.RED +
                    "https://www.youtube.com/JakePaul");
            return true;
        }
        return true;
    }
}
