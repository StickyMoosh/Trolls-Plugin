package com.sticky.trolls;

import com.sticky.trolls.commands.*;
import com.sticky.trolls.events.CoinFlipEvent;
import com.sticky.trolls.events.TrollEvents;
import com.sticky.trolls.items.ItemManager;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

public class Trolls extends JavaPlugin {

    @Override
    public void onEnable() {
        ItemManager.init();
        getServer().getPluginManager().registerEvents(new TrollEvents(), this);
        getServer().getPluginManager().registerEvents(new CoinFlipEvent(), this);
        getCommand("jakepaul").setExecutor(new JakePaul());
        getCommand("loganpaul").setExecutor((new LoganPaul()));
        getCommand("launch").setExecutor((new Launch()));
        getCommand("givesmitestick").setExecutor((new GiveSmiteStick()));
        getCommand("coinflip").setExecutor((new HeadsOrTails()));
        getServer().getConsoleSender().sendMessage(ChatColor.GREEN + "[Trolls]: Plugin is enabled");
    }

    @Override
    public void onDisable() {
        getServer().getConsoleSender().sendMessage(ChatColor.RED + "[Trolls]: Plugin is disabled");
    }

}
