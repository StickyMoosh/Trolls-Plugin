package com.sticky.trolls.events;

import com.sticky.trolls.inventories.CoinFlip;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class CoinFlipEvent implements Listener {

    @EventHandler
    public void onCLick(InventoryClickEvent e) {
        if (e.getClickedInventory() == null) { return; }
        if(e.getClickedInventory().getHolder() instanceof CoinFlip) {
            e.setCancelled(true);
            Player player = (Player) e.getWhoClicked();
            if(e.getCurrentItem() == null) { return; }
            if(e.getCurrentItem().getType() == Material.LAPIS_BLOCK) {
                player.sendMessage(ChatColor.RED + "You chose " + ChatColor.GOLD + "Heads " + ChatColor.RED + "but it was " + ChatColor.GOLD + "Tails!");
                player.closeInventory();
                player.setHealth(0.0D);
            }
            if(e.getCurrentItem().getType() == Material.GOLD_BLOCK) {
                player.sendMessage(ChatColor.RED + "You chose " + ChatColor.GOLD + "Tails " + ChatColor.RED + "but it was " + ChatColor.GOLD + "Heads!");
                player.closeInventory();
                player.setHealth(0.0D);
            }
            else if(e.getCurrentItem().getType() == Material.BOOK) {
                player.sendMessage(ChatColor.RED + "You chose " + ChatColor.GOLD + "neither, " + ChatColor.RED + "which was not an option!");
                player.closeInventory();
                player.setHealth(0.0D);
            }
        }
    }
}
