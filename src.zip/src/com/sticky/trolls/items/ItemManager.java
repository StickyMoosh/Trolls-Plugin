package com.sticky.trolls.items;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ItemManager {

    public static ItemStack smitestick;
    public static ItemStack diamonddirt;

    public static void init() {
        createSmitestick();
        createDiamondDirt();
    }

    private static void createSmitestick() {
        ItemStack item = new ItemStack(Material.BLAZE_ROD, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + "Smite Stick");
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.DARK_BLUE + "This powerful stick can");
        lore.add(ChatColor.DARK_BLUE + "create lightning wherever");
        lore.add(ChatColor.DARK_BLUE + "it is used.");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        smitestick = item;
    }

    private static void createDiamondDirt() {
        ItemStack item = new ItemStack(Material.DIRT, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + "Diamond Dirt");
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GOLD + "A normal dirt block.");
        lore.add(ChatColor.GOLD + "What did you expect?");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        diamonddirt = item;

        ShapedRecipe sr = new ShapedRecipe(NamespacedKey.minecraft("diamonddirt"), item);
        sr.shape("XXX",
                 "XYX",
                 "XXX");
        sr.setIngredient('X', Material.DIAMOND);
        sr.setIngredient('Y', Material.DIRT);
        Bukkit.getServer().addRecipe(sr);
    }

}
